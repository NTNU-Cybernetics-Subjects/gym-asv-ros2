
# INFO

- Trained for 1 000 000 timesteps.
- Took ca 1 Hour
- Used closure reward.
- Used random dock configuration x = +- 20 and y = [5,20]
- observation space: [surge, sway, yaw, relative_dock_position_x,
relative_dock_position_y]

